mkdir -p ~/.streamlit/credentials.toml

echo "\
[server]\n\
port =$PORT\n\
enablesCORS = false\n\
headless = true\n\
\n\
" > ~/.strealit/config.toml